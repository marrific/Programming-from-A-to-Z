var fs = require('fs'),
path = require('path'),
Twit = require('twit'),
config = require(path.join(__dirname, 'config.js'));

var T = new Twit(config);

////////// FLICKR //////////

var url;
var urlArray =[]; 
var downloadedPic;




var Twit = require('twit')

var fs = require('fs'),
path = require('path'),
Twit = require('twit'),
config = require(path.join(__dirname, 'config.js'));

var T = new Twit(config);


var Flickr = require("flickrapi"),
flickrOptions = {
  api_key: "86226b6dfd884478d7f801a6d7b23312",
  secret: "afce97664f506779"
};

    //console.log(Flickr);

    Flickr.tokenOnly(flickrOptions, function(error, flickr) {



      flickr.photos.search({
        user_id: "marrific",
        page: 1,
        per_page: 1
      }, function(err, result) {
        if(err){
          console.log(err);
        }
      // console.log(result);

      for( i = 0; i < result.photos.photo.length; i++){
        var count = result.photos.photo.length;
        console.log(count);
        var myFirstPic = result.photos.photo[i];
        photoId = {photo_id : myFirstPic.id};

        flickr.photos.getSizes(photoId, function(err, result) {
          if(err){
            console.log(err);
          }
          var url = result.sizes.size[8].source;
          console.log(url);

          download(url, 'google.png', function(){
            upload_random_image();



          });

        });
      }

    });

    });



/////////////////////// request pic /////////



console.log()

var fs = require('fs'),
request = require('request');

var download = function(uri, filename, callback){
  request.head(uri, function(err, res, body){
    console.log('content-type:', res.headers['content-type']);
    console.log('content-length:', res.headers['content-length']);

    request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
  });
};




function upload_random_image(){





  console.log('Opening an image...');
  var image_path = 'google.png'
  b64content = fs.readFileSync(image_path, { encoding: 'base64' });

  console.log('Uploading an image...');

  T.post('media/upload',{ media_data: b64content } ,  function (err, data, response) {

    if (err){
      console.log('ERROR');
      console.log(err);
    }
    else{
      console.log('Uploaded an image!');
  var tweet = 'Take a look at : http://bit.ly/2dX21cu  \n \n  #photography #marcelanowak #POD #flickr';

      T.post('statuses/update', {
        media_ids: new Array(data.media_id_string),
        status: tweet
      },
      function(err, data, response) {
        if (err){
          console.log('Error!');
          console.log(err);
        }
        else{
          console.log('Posted an image!');
        }
      }
      );
    }
  });
}

 /*setInterval(
   upload_random_image(),
   10000
   );*/



