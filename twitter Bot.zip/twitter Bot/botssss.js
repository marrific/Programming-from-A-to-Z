var fs = require('fs'),
path = require('path'),
Twit = require('twit'),
config = require(path.join(__dirname, 'config.js'));

var T = new Twit(config);

////////// FLICKR //////////

var url;
var urlArray =[]; 
var downloadedPic;




var Twit = require('twit')

var fs = require('fs'),
    path = require('path'),
    Twit = require('twit'),
    config = require(path.join(__dirname, 'config.js'));

var T = new Twit(config);

function pick_random_cute_animal(){
  var cute_animals = [
    'google.png',
    '1.png',
    '2.png',
    '3.png',
    '4.png'
  ];
  return cute_animals[Math.floor(Math.random() * cute_animals.length)];
}
































var Flickr = require("flickrapi"),
flickrOptions = {
  api_key: "86226b6dfd884478d7f801a6d7b23312",
  secret: "afce97664f506779"
};

    //console.log(Flickr);

    Flickr.tokenOnly(flickrOptions, function(error, flickr) {
  //console.dir(flickr);
  // we can now use "flickr" as our API object,
  // but we can only call public methods and access public data

  //flickr.photos.getRecent({
    flickr.photos.search({
      user_id: "marrific",
      page: 1,
      per_page: 1
    }, function(err, result) {
      if(err){
        console.log(err);
      }
      // console.log(result);

      for( i = 0; i < result.photos.photo.length; i++){
        var myFirstPic = result.photos.photo[i];
        photoId = {photo_id : myFirstPic.id};

        flickr.photos.getSizes(photoId, function(err, result) {
          if(err){
            console.log(err);
          }
          var url = result.sizes.size[7].source;
          urlArray.push(url); 
         //console.log(url);
         //tweeter(url);
         //console.log(myUrl.url)

         //url.toString() = downloadedPic;
         //console.log(downloadedPic);

         console.log(urlArray)
        // var myFirstPic = result.photos.photo[0];
        // console.log(myFirstPic);

        // console.log("https://farm" + myFirstPic.farm + ".staticflickr.com/" + myFirstPic.server + "/" + myFirstPic.id + "_" + myFirstPic.secret + ".jpg");

      });
      }

    });

  });



/////////////////////// request pic /////////



console.log()

var fs = require('fs'),
request = require('request');

var download = function(uri, filename, callback){
  request.head(uri, function(err, res, body){
    console.log('content-type:', res.headers['content-type']);
    console.log('content-length:', res.headers['content-length']);

    request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
  });
};

var koko = 'https://farm9.staticflickr.com/8407/30009667902_88cbd15329_s.jpg'

download(koko, 'google.png', function(){
  console.log('done');


});







function upload_random_image(){
  console.log('Opening an image...');
  var image_path = path.join(__dirname, '/cute-animals/' + pick_random_cute_animal()),
      b64content = fs.readFileSync(image_path, { encoding: 'base64' });

  console.log('Uploading an image...');

  T.post('media/upload', { media_data: b64content }, function (err, data, response) {
    if (err){
      console.log('ERROR');
      console.log(err);
    }
    else{
      console.log('Uploaded an image!');

      T.post('statuses/update', {
        media_ids: new Array(data.media_id_string)
      },
        function(err, data, response) {
          if (err){
            console.log('Error!');
            console.log(err);
          }
          else{
            console.log('Posted an image!');
          }
        }
      );
    }
  });
}

setInterval(
  upload_random_image(),
  10000
);



