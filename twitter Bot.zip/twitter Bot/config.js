// Change this file to config.js
// Add your keys
// Add file .gitignore: config.js
// Load with 
// var config = require('./config.js');

module.exports = {
  consumer_key:         'paCAB09Tp9jUWqotnOIzKpAa1', 
  consumer_secret:      'oeESUFQ2qykbZh6adbSstov3qdoxlnK0m3NaShpiHxHRZsnRbl',
  access_token:         '780784852761063424-cRN95bfE6dg1zxxCy8YmIRKOWxjrBYh',
  access_token_secret:  'H4zz3QRJ520RLkjFqIHR6kz33CjiL8De75a5gTfiR1tuI'
}